let img;
let rSlider,bSlider,gSlider;


function preload(){
  img = loadImage('papaross.png');
}

function setup() {
  createCanvas(600, 400);
  textSize(15);
  
  rSlider = createSlider(0, 255, 100);
  rSlider.position(330, 20);
  gSlider = createSlider(0, 255, 0);
  gSlider.position(330, 50);
  bSlider = createSlider(0, 255, 255);
  bSlider.position(330, 80);
}
//draws ross and his aethereal masterpiece
function draw() {
  const r = rSlider.value();
  const g = gSlider.value();
  const b = bSlider.value();
  
  image(img,0,0);
  rect(0,52,190,267);
  fill(r,g,b);
  text('red', rSlider.x * 2 + rSlider.width, 35);
  text('green', gSlider.x * 2 + gSlider.width, 65);
  text('blue', bSlider.x * 2 + bSlider.width, 95);
}

 